from flask import Flask, render_template, request, redirect, session, url_for, flash
import csv
import random
from translations import translations

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.url_map.strict_slashes = False

supported_languages = ['en', 'hi', 'mr', 'ta', 'te', 'bn', 'ml', 'gu', 'kn', 'ur']
language_labels = {
    'en': 'English', 'hi': 'हिंदी', 'mr': 'मराठी', 'ta': 'தமிழ்', 'te': 'తెలుగు',
    'bn': 'বাংলা', 'ml': 'മലയാളം', 'gu': 'ગુજરાતી', 'kn': 'ಕನ್ನಡ', 'ur': 'اردو'
}

@app.route('/set_language/<lang>')
def set_language(lang):
    if lang in supported_languages:
        session['lang'] = lang
    return redirect(request.referrer or url_for('home'))

@app.route('/')
def home():
    lang = session.get('lang', 'en')
    return render_template('index.html', translate=translations[lang], lang_labels=language_labels)

@app.route('/donor', methods=['GET', 'POST'])
def donor():
    if 'username' not in session:
        return redirect(url_for('login'))
    lang = session.get('lang', 'en')

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        aadhaar = request.form['aadhaar']
        phone = request.form['phone']
        organ = request.form['organ']
        blood = request.form['blood']
        location = request.form['location']
        otp_aadhaar_entered = request.form.get('otp_aadhaar', '')

        if not aadhaar or 'otp_aadhaar' not in session:
            flash(translations[lang].get('otp_not_sent_aadhaar', 'Please enter Aadhaar number and request OTP.'))
            return redirect(url_for('donor'))

        if len(otp_aadhaar_entered) != 6 or not otp_aadhaar_entered.isdigit() or otp_aadhaar_entered != session.get('otp_aadhaar'):
            flash(translations[lang].get('invalid_aadhaar_otp', 'Aadhaar OTP verification failed.'))
            return redirect(url_for('donor'))

        with open('donors.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([name, email, aadhaar, phone, organ, blood, location])

        session.pop('otp_aadhaar', None)

        return render_template('thankyou.html', translate=translations[lang], name=name, email=email, organ=organ, lang_labels=language_labels)

    return render_template('donor.html', translate=translations[lang], lang_labels=language_labels,
                           otp_aadhaar=session.get('otp_aadhaar', ''))

@app.route('/generate_otp/<field>')
def generate_otp(field):
    if field == 'aadhaar':
        session['otp_aadhaar'] = str(random.randint(100000, 999999))
        return session['otp_aadhaar']
    return "Invalid"

@app.route('/finder', methods=['GET', 'POST'])
def finder():
    if 'username' not in session:
        return redirect(url_for('login'))
    lang = session.get('lang', 'en')
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        aadhaar = request.form['aadhaar']
        phone = request.form['phone']
        organ = request.form['organ']
        blood = request.form['blood']
        location = request.form['location']
        otp_aadhaar_entered = request.form.get('otp_aadhaar', '')

        if not aadhaar or 'otp_aadhaar' not in session:
            flash(translations[lang].get('otp_not_sent_aadhaar', 'Please enter Aadhaar number and request OTP.'))
            return redirect(url_for('finder'))

        if len(otp_aadhaar_entered) != 6 or not otp_aadhaar_entered.isdigit() or otp_aadhaar_entered != session.get('otp_aadhaar'):
            flash(translations[lang].get('invalid_aadhaar_otp', 'Aadhaar OTP verification failed.'))
            return redirect(url_for('finder'))

        with open('finders.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([name, email, aadhaar, phone, organ, blood, location])

        matches = []
        try:
            with open('donors.csv', 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) < 7:
                        continue
                    d_name, d_email, _, _, d_organ, d_blood, d_location = row
                    if organ == d_organ and blood == d_blood:
                        matches.append((d_name, d_email, d_location))
        except FileNotFoundError:
            matches = []

        session.pop('otp_aadhaar', None)

        if matches:
            same_location = [m for m in matches if m[2] == location]
            other_location = [m for m in matches if m[2] != location]
            return render_template('matched.html', translate=translations[lang], 
                                   same_location=same_location, other_location=other_location,
                                   lang_labels=language_labels)
        else:
            return render_template('thankyou.html', translate=translations[lang], name=name, email=email, organ=organ, lang_labels=language_labels)

    return render_template('finder.html', translate=translations[lang], lang_labels=language_labels,
                           otp_aadhaar=session.get('otp_aadhaar', ''))

@app.route('/donate')
def donate():
    lang = session.get('lang', 'en')
    return render_template('donation.html', translate=translations[lang], lang_labels=language_labels)

@app.route('/contact')
def contact():
    lang = session.get('lang', 'en')
    return render_template('contact.html', translate=translations[lang], lang_labels=language_labels)

@app.route('/login', methods=['GET', 'POST'])
def login():
    lang = session.get('lang', 'en')
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        try:
            with open('users.csv', 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) < 3:
                        continue
                    if row[1] == email and row[2] == password:
                        session['username'] = row[0]
                        return redirect(url_for('home'))
        except FileNotFoundError:
            pass
        return render_template('login.html', translate=translations[lang], error=translations[lang].get('invalid_credentials', 'Invalid credentials'), lang_labels=language_labels)

    return render_template('login.html', translate=translations[lang], lang_labels=language_labels)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    lang = session.get('lang', 'en')
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        with open('users.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([name, email, password])

        session['username'] = name
        return redirect(url_for('home'))

    return render_template('signup.html', translate=translations[lang], lang_labels=language_labels)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
